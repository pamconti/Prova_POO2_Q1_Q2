﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P2_Questao1
{
    internal class onibus : veiculos
    {
        private const int AnoAtual = 2024;
        private int assentos;

        public onibus(string _placa, int _ano, int _assentos) : base(_placa, _ano)
        {
            this.assentos = _assentos;
            this.Placa = _placa;
            this.Ano = _ano;
        }

        override public string diaria()
        {
            int diariaCalculada = (30 * assentos) - (AnoAtual - this.Ano) * 70;
            return $"R${diariaCalculada},00";
        }

        public int Assentos { get => assentos; set => assentos = value; }
    }
}