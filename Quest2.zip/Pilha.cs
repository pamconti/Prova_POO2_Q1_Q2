﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Pilha
{
    private Stack<string> pilha;

    public Pilha()
    {
        pilha = new Stack<string>();
    }

    public void AdicionarPeca(string peca)
    {
        pilha.Push(peca);
    }

    public void SubstituirPeca(string pecaVelha, string pecaNova)
    {
        Stack<string> tempPilha = new Stack<string>();
        string pecaAtual;

        Console.WriteLine("Iniciando a substituição da peça...");

        while (pilha.Count > 0)
        {
            pecaAtual = pilha.Pop();
            Console.WriteLine($"Retirando peça: {pecaAtual}");
            if (pecaAtual == pecaVelha)
            {
                Console.WriteLine($"Substituindo peça: {pecaVelha} por {pecaNova}");
                tempPilha.Push(pecaNova);
                break;
            }
            else
            {
                tempPilha.Push(pecaAtual);
            }
        }

        while (tempPilha.Count > 0)
        {
            string pecaParaRecolocar = tempPilha.Pop();
            Console.WriteLine($"Recolocando peça: {pecaParaRecolocar}");
            pilha.Push(pecaParaRecolocar);
        }

        Console.WriteLine("Substituição concluída!");
    }

    public void MostrarPilha()
    {
        Console.WriteLine("Peças na pilha:");
        foreach (var peca in pilha)
        {
            Console.WriteLine(peca);
        }
    }
}
