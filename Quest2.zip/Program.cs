﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Quest2
{
   class Program
        {
            static void Main(string[] args)
            {
                Pilha pilha = new Pilha();
                pilha.AdicionarPeca("Cúpula de Vidro");
                pilha.AdicionarPeca("Lâmpada");
                pilha.AdicionarPeca("Hélice");

                Console.WriteLine("Antes da substituição:");
                pilha.MostrarPilha();

                Console.Write("Digite o nome da peça a ser substituída: ");
                string pecaVelha = Console.ReadLine();

                Console.Write("Digite o nome da nova peça: ");
                string pecaNova = Console.ReadLine();

                pilha.SubstituirPeca(pecaVelha, pecaNova);

                Console.WriteLine("Depois da substituição:");
                pilha.MostrarPilha();
            }
        }
    
    
}
